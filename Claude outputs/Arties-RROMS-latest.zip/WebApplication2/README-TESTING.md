# Artie's RROMS – how to run and test

## 1. Open the project
1. Unzip this folder anywhere (e.g. `Documents\RROMS`).
2. Double-click **WebApplication2.slnx** to open it in **Visual Studio 2026**.
3. Wait for NuGet packages to restore (bottom-left status bar), then **Build > Build Solution** (Ctrl+Shift+B).

## 2. Create the database (first time only)
Open **Tools > NuGet Package Manager > Package Manager Console** and run:

```
Update-Database
```

All migrations (including AddFeedbackReply) are already in the Migrations folder.
This creates a local SQL Server database called **RROMS** on `(localdb)\mssqllocaldb`
and fills it with the sample restaurant, tables, menu and test accounts.

## 3. Run
Press **F5** (or the green ▶ https button).

## 4. Test accounts
| Role     | Email                | Password     | Login page |
|----------|----------------------|--------------|------------|
| Admin    | admin@rroms.com      | Admin@123    | Staff login |
| Staff    | staff@rroms.com      | Staff@123    | Staff login |
| Customer | customer@rroms.com   | Customer@123 | Normal login (or register a new one) |

Google / Facebook / Microsoft login buttons won't work on your PC (the keys are private). Use email + password.

## 5. What to test
**Customer**
- Register, log in, edit profile
- Book a table, modify it, cancel it (My Reservations)
- Browse the menu, add to cart, checkout, view receipt
- My Orders: watch the status tracker change while staff update the order
- My Reviews: rate a completed visit

**Staff**
- Today's Reservations: confirm, check-in, modify, complete, no-show, cancel
- Active Orders: move orders Pending → Preparing → Ready → Served
- Billing: view bill, adjust with a reason, settle (Cash/Card), print receipt
- Feedback: see recent reviews

**Admin**
- Dashboard numbers and revenue chart
- Restaurant (areas, tables, hours) and Menu (categories, items, availability)
- Users: add a staff account, edit it, suspend/activate, try delete
- Orders: orders and payments tabs
- Reviews: filter, search, reply to a review
- Reports: try each report type and date range, then Export to CSV

## 6. Reporting bugs
For each problem, send: the page URL, what you clicked, what you expected, and a screenshot of the error.
